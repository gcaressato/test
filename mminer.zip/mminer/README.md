mminer v.1.0.0
by B_S_Z

This is updated version of Mist miner- bchd_mist_miner_v1 (https://mistcoin.org)

package.json, package-lock.json - updated npm packages
generateV1.ts - updated for slpjs v.0.27.8, grpc-bchrpc-node v.0.11.3, added fastmine for windows, BigNumber error fix and utxo filter

mminer v.1.0.0 is prepared for mining MAZE on Windows. If you want to mine other tokens (Mist, dSLP or BTCL) delete or replace .cache file and change .env file with other tokens environment (TOKEN_INIT_REWARD_V1, TOKEN_HALVING_INTERVAL_V1, MINER_DIFFICULTY_V1, TOKEN_START_BLOCK_V1,TOKEN_ID_V1) and paste your WIF (address private key)

Install:
nodejs 14.15.0 with necessary files
git for windows
Electron Cash wallet (SLP edition) - prepare the wallet for mining (pick your mining address, send multiple 0.00001870 BCH  in one transaction to this address - send tab - pay to)

Open command line (e.g. PowerShell) and run:

npm i -g npm@7.0.6

Navigate to the miner directory and run:

npm i
npm start

Ctrl C - to stop the miner